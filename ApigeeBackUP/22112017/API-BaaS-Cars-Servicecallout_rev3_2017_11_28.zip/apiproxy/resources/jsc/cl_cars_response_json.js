try{
    // Cleaning up Cars content
    var carsSourceObj = JSON.parse(context.getVariable('response.content'));
    
    delete(carsSourceObj.params);
    delete(carsSourceObj.action);
    delete(carsSourceObj.application);   
    
    var cleanRatingsObj = {};
    cleanRatingsObj = carsSourceObj.entities;
    for(var i =0; i < cleanRatingsObj.length; i++){
        delete(cleanRatingsObj[i].uuid);
        delete(cleanRatingsObj[i].type);
        delete(cleanRatingsObj[i].created);
        delete(cleanRatingsObj[i].modified);
        delete(cleanRatingsObj[i].metadata);
    }
    context.setVariable('response.content', JSON.stringify(cleanRatingsObj));
    
    // Cleaning up Ratings content
    var ratingSourceObj = JSON.parse(context.getVariable('ratingsResponse.content'));
    
    delete(ratingSourceObj.params);
    delete(ratingSourceObj.action);
    delete(ratingSourceObj.application);  
    
    var cleanRatingsObj = {};
    cleanRatingsObj = ratingSourceObj.entities;
    for(var i =0; i < cleanRatingsObj.length; i++){
        delete(cleanRatingsObj[i].uuid);
        delete(cleanRatingsObj[i].type);
        delete(cleanRatingsObj[i].created);
        delete(cleanRatingsObj[i].modified);
        delete(cleanRatingsObj[i].metadata);
    }
    context.setVariable('ratingsResponse.content', JSON.stringify(cleanRatingsObj));
}catch(exception){
    context.setVariable = {'js_error': exception.message}
}