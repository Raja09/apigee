var apigee = require('apigee-access');
var http = require('http');
var https = require('https');

var kvm = apigee.getKeyValueMap('raja0903', 'environment');
  kvm.get('username', function(err, key_value) {
    //Use the key value here. For example the following assigns the value
    //to a 'kvmvalue' variable in the response, which can be used by policies:
    apigee.setVariable(response, 'kvmvalue', key_value);
});

http.createServer(function (request, response) {
  //Get the Auth Key
  //Call my API Endpoint
  //Return the result
}).listen(8124);//arbitrary port?