response.content = '';
response.headers['Content-Type'] = 'application/json';

try{
    
    //var resStatus = context.targetResponse.status; 
    
    // var res = {};
    var req_verb = context.getVariable('request.verb');
    var req_uri = context.getVariable('request.uri');
    var req_org = context.getVariable('organization.name');
    var req_apiName = context.getVariable('apiproxy.name');
    var req_env = context.getVariable('environment.name');
    // var targetServerResCode = status; //context.getVariable('response.status.code');
    
    //var response1 = context.getVariable("newrequest.content");//return the response form target server;
    
    //'beachbody__test__content-api-programs-v2__default__/v2/programs__GET'
    var cacheKey = req_org+'__'+req_env+'__'+req_apiName+'__default__'+req_uri+'__'+req_verb;
    
    var cacheURL = 'https://api.usergrid.com/'+req_org+'/sandbox/caches';
    var headers = { 'Content-Type' : 'application/json', 'Accept' : 'application/json' };
    
    var res = {};
    var trendingProgramsURL = 'https://gist.githubusercontent.com/rsekhaross/18c3084c8d22d3cdcc47f52b876a00f8/raw/6387f2009dbb18639dd46fb006b46e88986d82ce/programs.json';
    //var headers = { 'Content-Type' : 'application/json', 'Accept' : 'application/json' };
    
    var trendingProgramReq = new Request(trendingProgramsURL, "GET", headers);
    var trendingProgramRes = httpClient.send(trendingProgramReq);
        
    trendingProgramRes.waitForComplete();
    
    trendingProgramsResponse = JSON.parse(trendingProgramRes.getResponse().content);

    if(trendingProgramsResponse.items.length > 0){
        var brandCodeArr = {};

        for(var i in trendingProgramsResponse) {
            for(var j in trendingProgramsResponse[i]){
                brandCodeArr[j] = trendingProgramsResponse[i][j].brandCode;
            }
        }
        
        var res = {};
    
        for(var i in brandCodeArr) {
              
            var brandCode = brandCodeArr[i];
            
            var programsURL = 'http://content-dom-origin.api.beachbodyondemand.com/v3/programs/'+brandCode;
            //var headers = { 'Content-Type' : 'application/json', 'Accept' : 'application/json' };
            
            var programReq = new Request(programsURL, "GET", headers);
            var programRes = httpClient.send(programReq);
            
            programRes.waitForComplete();
            programResponse = programRes.getResponse().content.asJSON;
    
            res[brandCode] = trendingProgramsResponse.items;
        }
        
        /* Update or Create the Cache */
        
        /*
        var temp1URI = '?limit=1&ql='+encodeURIComponent("select cacheResponse where cacheKey='"+cacheKey+"' order by created desc");
        var temp1URL = cacheURL+temp1URI;
        var temp1Req = new Request(temp1URL, 'GET', headers);
        var temp1Res = httpClient.send(temp1Req);
        
        temp1Res.waitForComplete();
        temp1Response = temp1Res.getResponse().content.asJSON;
        
        var body = {'cacheKey': cacheKey, 'cacheResponse': res};
        if(temp1Response.length > 0){
            var Req = new Request(cacheURL, "PUT", headers, JSON.stringify(body));
            var Res = httpClient.send(Req);
            
            Res.waitForComplete();
            Response = Res.getResponse().content.asJSON;
            
            //tempResponse = JSON.parse(res);
            //res = tempResponse.items;
        }else{
            var Req = new Request(cacheURL, "POST", headers, JSON.stringify(body));
            var Res = httpClient.send(Req);
            
            Res.waitForComplete();
            Response = Res.getResponse().content.asJSON;
            
            //tempResponse = JSON.parse(res);
            //res = tempResponse.items;
        }
        
        */
        
        /* Update or Create the Cache */
        
    }
    /*
    else{
        var temp1URI ='?limit=1&ql='+encodeURIComponent("select cacheResponse where cacheKey='"+cacheKey+"' order by created desc");
        var temp1URL = cacheURL+temp1URI;
        var Req = new Request(temp1URL, "GET", headers);
        var Res = httpClient.send(Req);
        
        Res.waitForComplete();
        Response = Res.getResponse().content.asJSON;
        
        //res = JSON.parse(Response.list);
        //res = res.items;
        res = Response.list;
    }
    */
    
    var body = response.content.asJSON;
    body.items = res;
    
}catch(err){
    response.content.asJSON.error = err;
}