response.content = '';
response.headers['Content-Type'] = 'application/json';

try{
    
    //var resStatus = context.targetResponse.status; 
    
    //var res = {};
    var req_verb = context.getVariable('request.verb');
    var req_uri = context.getVariable('request.uri');
    var req_org = context.getVariable('organization.name');
    var req_apiName = context.getVariable('apiproxy.name');
    var req_env = context.getVariable('environment.name');
    // var targetServerResCode = status; //context.getVariable('response.status.code');
    
    //var response1 = context.getVariable("newrequest.content");//return the response form target server;
    
    //'beachbody__test__content-api-programs-v2__default__/v2/programs__GET'
    var cacheKey = req_org+'__'+req_env+'__'+req_apiName+'__default__'+req_uri+'__'+req_verb;
    
    var cacheURL = 'https://api.usergrid.com/'+req_org+'/sandbox/caches';
    var headers = { 'Content-Type' : 'application/json', 'Accept' : 'application/json' };
    
    var res = {};
    var trendingVideosURL = 'https://gist.githubusercontent.com/rsekhaross/d768b373ee782b69254d14f42c04bb9c/raw/7489b7cf2c66a74954a5ededc7906505c0043996/video.json';
    var headers = { 'Content-Type' : 'application/json', 'Accept' : 'application/json' };
    
    var trendingVideosReq = new Request(trendingVideosURL, "GET", headers);
    var trendingVideosRes = httpClient.send(trendingVideosReq);
        
    trendingVideosRes.waitForComplete();
    
    trendingVideosResponse = JSON.parse(trendingVideosRes.getResponse().content);
    
    if(trendingVideosResponse.items.length > 0){
        var videoSlugArr = {};
    
        for(var i in trendingVideosResponse) {
            for(var j in trendingVideosResponse[i]){
                videoSlugArr[j] = trendingVideosResponse[i][j].slug;
            }
        }
        
        var res = {};
    
        for(var i in videoSlugArr) {
              
            var videoSlug = videoSlugArr[i];
            
            var videoURL = 'http://content-dom-origin.api.beachbodyondemand.com/videos/'+videoSlug;
            //var headers = { 'Content-Type' : 'application/json', 'Accept' : 'application/json' };
            
            var videoReq = new Request(videoURL, "GET", headers);
            var videoRes = httpClient.send(videoReq);
            
            videoRes.waitForComplete();
            videoResponse = videoRes.getResponse().content.asJSON;
    
            res[videoSlug] = videoResponse.items;
        }
        
        /* Update or Create the Cache */
        
        var temp1URI = '?limit=1&ql='+encodeURIComponent("select cacheResponse where cacheKey='"+cacheKey+"' order by created desc");
        var temp1URL = cacheURL+temp1URI;
        var temp1Req = new Request(temp1URL, 'GET', headers);
        var temp1Res = httpClient.send(temp1Req);
        
        temp1Res.waitForComplete();
        temp1Response = temp1Res.getResponse().content.asJSON;
        
        var body = {'cacheKey': cacheKey, 'cacheResponse': res};
        if(temp1Response.length > 0){
            var Req = new Request(cacheURL, "PUT", headers, JSON.stringify(body));
            var Res = httpClient.send(Req);
            
            Res.waitForComplete();
            Response = Res.getResponse().content.asJSON;
            
            //tempResponse = JSON.parse(res);
            //res = tempResponse.items;
        }else{
            var Req = new Request(cacheURL, "POST", headers, JSON.stringify(body));
            var Res = httpClient.send(Req);
            
            Res.waitForComplete();
            Response = Res.getResponse().content.asJSON;
            
            //tempResponse = JSON.parse(res);
            //res = tempResponse.items;
        }
        
        /* Update or Create the Cache */
    }else{
        var temp1URI ='?limit=1&ql='+encodeURIComponent("select cacheResponse where cacheKey='"+cacheKey+"' order by created desc");
        var temp1URL = cacheURL+temp1URI;
        var Req = new Request(temp1URL, "GET", headers);
        var Res = httpClient.send(Req);
        
        Res.waitForComplete();
        Response = Res.getResponse().content.asJSON;
        
        //res = JSON.parse(Response.list);
        //res = res.items;
        res = Response.list;
    }

        var body = response.content.asJSON;
        body.items = res;
    
}catch(err){
    response.content.asJSON.error = err;
}