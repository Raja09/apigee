var express = require('express');
var https = require('https');
var http = require('http');
var apigee = require('apigee-access');
var app = express();
var kvm = apigee.getKeyValueMap('orchestration', 'environment');
var baseUrl = '';
var authKey = '';
var sourceVideoDataUri = '';
var excerciseObject = [];
var profileId = '';
var activityUrl = '';
var exerciseId = '';

app.use(express.bodyParser());

// Handle GET : /orchestration-node-example
app.get('/', function(req, res) {
    var optionsGlobal = {
        host: baseUrl,
        sourceVideoDataUri: sourceVideoDataUri,
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': authKey,
        }
    };
    
    profileId = apigee.getVariable(req, "request.queryparam.profileId");
    exerciseId = apigee.getVariable(req, "request.queryparam.exerciseId")

    fetchExerciseHistory(optionsGlobal, res);
});


/**
 * fetchVideoGuids
 * Grab the videoGuids to fetch more details on
 * @param {object} optionsGlobal
 * @param {object} mainResponse
 */
function fetchExerciseHistory(optionsGlobal, mainResponse) {
    var options = optionsGlobal;
    
    var path = "/profiles/"+profileId+"/exercises"
    if(exerciseId != undefined){
        path = path +'/'+exerciseId;
    }
    
    var excersice = {
        host: activityUrl,
        path: path,
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    }
    
    http.request(excersice, function(response) {
        var body = '';
        var videoGuids = [];
        response.on('data', function(d) {
            body += d;
        });
        response.on('end', function() {
            try{
                excerciseObject = JSON.parse(body);
                var videoGuids = [];
                
                if(excerciseObject.errorCode == 1019 || excerciseObject.errorCode == 1005){
                    sendResponse(mainResponse, excerciseObject)
                }
                
                if(exerciseId != undefined){
                    videoGuids.push(excerciseObject.videoGuid);
                }else{
                    var excercises = excerciseObject.items;
                    var totalExcercises = excercises.length;
                    
                    if(totalExcercises > 0){
                        for(ex = 0; ex < totalExcercises; ex++ ){
                            videoGuids.push(excercises[ex].videoGuid);
                        }
                    }
                }
                fetchVideoDetails(videoGuids, optionsGlobal, mainResponse);
                
            }catch(e) {
                var error = {
                    "code": 2001,
                    "message": "Error in response format for " + excersice.path,
                }
                sendErrorResponse(response, error);
            }
            
        });
        
    }).end();
}

/**
 * fetchVideoDetails
 * Fetch the video content for the specified videoGuids
 * @param {string} videoGuids
 * @param {object} optionsGlobal
 * @param {object} mainResponse
 */
function fetchVideoDetails(videoGuidsArr, optionsGlobal, mainResponse) {
    var options = optionsGlobal;
    var videoGuids = videoGuidsArr.join();
    options.path = optionsGlobal.sourceVideoDataUri + '?videoGuid=' + videoGuids;
    https.request(options, function(videoDetailsResponse) {
        var body = '';
        videoDetailsResponse.on('data', function(d) {
            body += d;
        });
        
        // videoDetailsResponse.on('error', function(e){
        //     var jsonResponse = JSON.stringify(excerciseObject);
        //     mainResponse.send(jsonResponse);
        //     sendResponse(mainResponse, jsonResponse);
        // });
        
        videoDetailsResponse.on('end', function() {
            try {
                var videoObject = JSON.parse(body);
                var total = (videoObject.hits && videoObject.hits.records) || 0;
                var videoData = {};
                var videoDataSorted = [];

                if (total) {
                    for (var x = 0; x < total; x++) {
                        videoGuid = videoObject.items[x].videoGuid || '';
                        workoutTitle = videoObject.items[x].title || '';
                        programTitle = videoObject.items[x].programTitle || '';
                        images = videoObject.items[x].images || {};
                        videoData[videoGuid] = {
                            videoGuid: videoGuid,
                            programTitle: programTitle,
                            programImage: images,
                            workoutTitle: workoutTitle,
                        }
                    }
                }
                
                if(exerciseId){
                    
                    excerciseObject.videoTitle = '';
                    excerciseObject.programTitle = '';
                    excerciseObject.videoImage = [];
                    
                    if(videoObject.errorCode != 1003){
                        excerciseObject.videoTitle = videoData[videoGuid].workoutTitle;
                        excerciseObject.programTitle = videoData[videoGuid].programTitle;
                        excerciseObject.videoImage.push(videoData[videoGuid].programImage);
                    }
                }else{
                    // Merge the Excercise and Video data in the order it was requested
                    for(ex=0; ex < excerciseObject.items.length; ex++){
                        
                        exVideoGuid = excerciseObject.items[ex].videoGuid;
                        
                        excerciseObject.items[ex]['videoTitle'] = '';
                        excerciseObject.items[ex]['programTitle'] = '';
                        excerciseObject.items[ex]['videoImage'] = [];
                        
                        if(videoData[exVideoGuid]){
                            excerciseObject.items[ex]['videoTitle'] = videoData[videoGuid].workoutTitle;
                            excerciseObject.items[ex]['programTitle'] = videoData[videoGuid].programTitle;
                            excerciseObject.items[ex]['videoImage'].push(videoData[videoGuid].programImage);
                        }
                    }
                }
                
                var jsonResponse = JSON.stringify(excerciseObject);
                sendResponse(mainResponse, jsonResponse);
                
                // }else {
                //     excerciseObject.videoTitle = '';
                //     excerciseObject.programTitle = '';
                //     excerciseObject.videoImage = [];
                    
                //     var jsonResponse = JSON.stringify(excerciseObject);
                //     sendResponse(mainResponse, jsonResponse);
                    
                    
                    
                    // var error = {
                    //     "code": 2002,
                    //     "message": "No video data found in content microservice video",
                    // }
                    // sendErrorResponse(mainResponse, error);
                // }
            } catch(e) {
                var error = {
                    "code": 2003,
                    "message": "Error in response format for content microservice video.",
                }
                sendErrorResponse(mainResponse, error);
            }

        });
    }).end();
}

/**
 * sendErrorResponse
 * Send the response out
 * @param {object} resp
 * @param {string} json
 */
function sendErrorResponse(resp, error) {
    error = {
        "errorCode": error.code,
        "module": "EHS-orchestration",
        "userMessage": error.message,
        "debugMessage": error.message,
        "link": ""
    };
    var json = JSON.stringify(error);
    sendResponse(resp, json);
}

/**
 * sendResponse
 * Send the response out
 * @param {object} resp
 * @param {string} json
 */
function sendResponse(resp, json) {
    resp.setHeader('content-type', 'application/json');
    resp.send(json);
}

/**
 * hangleConfigValue
 * Get the KVM value by keyName
 * @param {string} keyName
 */
function hangleConfigValue(keyName) {
    kvm.get(keyName, function(err, keyValue) {
        setConfigData(err, keyValue, keyName);
    });
}

/**
 * setConfigData
 * Set global variable of config key/value
 * @param {object} err
 * @param {string} keyValue
 * @param {string} field
 */
function setConfigData(err, keyValue, field) {
    eval(field + " = '" + keyValue + "';");
}

// Listen for requests until the server is stopped
app.listen(9000);

// Init pull and set config data
kvm.getKeys(function(err, keysArray) {
    for (var idx = 0; idx < keysArray.length; idx++) {
        key = keysArray[idx];
        hangleConfigValue(key);
    }
});
