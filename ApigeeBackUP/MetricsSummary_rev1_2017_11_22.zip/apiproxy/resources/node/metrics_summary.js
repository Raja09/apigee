var express = require('express');
var https = require('https');
var http = require('http');
var apigee = require('apigee-access');
var app = express();
var kvm = apigee.getKeyValueMap('metrics-summary', 'environment');
var baseUrl = '';
var authKey = '';
var sourceMetricsUri  = '';
var sourceEHSUri  = '';
var guid = '';
var biometricId = '';
var devicePlatform = '';
var devicePlatformDetails = '';


app.use(express.bodyParser());

// Handle GET : /metricssummary
app.get('/', function(req, res) {
    var optionsGlobal = {
        host: baseUrl,
        sourceMetricsUri: sourceMetricsUri,
        sourceEHSUri: sourceEHSUri,
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': authKey,
        }
    };

    guid = apigee.getVariable(req, 'request.queryparam.profileId');
    biometricId = apigee.getVariable(req, 'request.queryparam.biometricId');
    devicePlatform = apigee.getVariable(req, 'request.queryparam.devicePlatform');
    devicePlatformDetails = apigee.getVariable(req, 'request.queryparam.devicePlatformDetails');
    
    fetchDetailsFromMetrics(optionsGlobal, res);
});

/**
 * Fetch details from Metrics API
 *
 * @param {object} optionsGlobal
 * @param {object} mainResponse
 */
function fetchDetailsFromMetrics(optionsGlobal, mainResponse){
    var options = optionsGlobal;
    options.path = optionsGlobal.sourceMetricsUri + '?profileId=' + guid +'&biometricId='+biometricId;
    
    https.request(options, function(response) {
        var body = '';
        response.on('data', function(d) {
            body += d;
        });
        response.on('end', function() {
            try{
                if(devicePlatform == undefined && devicePlatformDetails == undefined){
                    sendResponse(mainResponse, JSON.parse(body));
                }else{
                    metricsJsonObj = JSON.parse(body);
                    
                    var metricsArr = {};
                    var metrics = [];
                    metricsArr['profileID'] = metricsJsonObj[0]['profileID'];
                    metricsArr['videoGuid'] = metricsJsonObj[0]['videoGuid'];
                    metricsArr['platform'] = metricsJsonObj[0]['sourceSystem'];
                    metricsArr['biometricDevice'] = metricsJsonObj[0]['deviceType'];
                    metricsArr['exerciseDate'] = '';
                    metricsArr['exerciseDuration'] = metricsJsonObj[0]['duration'];
                    metricsArr['exerciseData'] = [];
                    
                    var rawData = JSON.parse(metricsJsonObj[0]['rawData']);
                    
                    for(i=0; i < rawData.length; i++){
                        if(i==0){
                            metricsArr['exerciseDate'] = rawData[i].dtStart;
                        }
                        var dtStart = new Date(rawData[i].dtStart.replace('-','/'));
                        var dtEnd = new Date(rawData[i].dtEnd.replace('-','/'));
                        
                        var duration = Math.abs(dtEnd - dtStart);
                        
                        exerciseData = {
                            basalCalories: 0,
                            startAt: rawData[i].dtStart,
                            duration: duration,
                            heartRate: rawData[i].hr,
                            activeCalories: 0
                        };
                        
                        metricsArr['exerciseData'].push(exerciseData);
                    }
                    
                    metricsArr['biometricDeviceDetails'] = 'migration';
                    metricsArr['biometricDevicePlatform'] = 'migration';
                    metricsArr['platformDetails'] = 'migration';
                    metricsArr['exerciseType'] = 'bb-workout';

                    metrics.push(metricsArr);
                    sendResponse(mainResponse, JSON.stringify(metrics));
                }
            }catch(e){
                var error = {
                    "code": 2001,
                    "message": "Error in response format for " + options.path,
                }
                sendErrorResponse(response, error);
            }
        });
    }).end();
}

/**
 * Fetch Exercise History details for Metrics
 *
 * @param {object} optionsGlobal
 * @param {object} mainResponse
 */
function fetchMetricsMigrationDetails(optionsGlobal, mainResponse){
    var options = optionsGlobal;
    options.path = optionsGlobal.sourceEHSUri;
    http.request(options,function(response){
        var body = '';
        response.on('data', function(d){
           body += d;
        });
        response.on('end', function(){
            try{
                sendResponse(mainResponse, JSON.parse(body));
            }catch(e){
                 var error = {
                    "code": 2001,
                    "message": "Error in response format for " + options.path,
                }
                sendErrorResponse(response, error);
            }
        });
    }).end();
    
}


/**
 * sendErrorResponse
 * Send the response out
 * @param {object} resp
 * @param {string} json
 */
function sendErrorResponse(resp, error) {
    error = {
        "errorCode": error.code,
        "module": "Matrics-Summary",
        "userMessage": error.message,
        "debugMessage": error.message,
        "link": ""
    };
    var json = JSON.stringify(error);
    sendResponse(resp, json);
}

/**
 * sendResponse
 * Send the response out
 * @param {object} resp
 * @param {string} json
 */
function sendResponse(resp, json) {
    resp.setHeader('content-type', 'application/json');
    resp.send(json);
}

/**
 * hangleConfigValue
 * Get the KVM value by keyName
 * @param {string} keyName
 */
function hangleConfigValue(keyName) {
    kvm.get(keyName, function(err, keyValue) {
        setConfigData(err, keyValue, keyName);
    });
}

/**
 * setConfigData
 * Set global variable of config key/value
 * @param {object} err
 * @param {string} keyValue
 * @param {string} field
 */
function setConfigData(err, keyValue, field) {
    eval(field + " = '" + keyValue + "';");
}

// Listen for requests until the server is stopped
app.listen(9000);

// Init pull and set config data
kvm.getKeys(function(err, keysArray) {
    for (var idx = 0; idx < keysArray.length; idx++) {
        key = keysArray[idx];
        hangleConfigValue(key);
    }
});
