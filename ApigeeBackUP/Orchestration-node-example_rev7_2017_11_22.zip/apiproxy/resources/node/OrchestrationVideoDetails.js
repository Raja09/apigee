var express = require('express');
var https = require('https');
var apigee = require('apigee-access');
var app = express();
var baseUrl = '';
var authKey = '';
var sourceVideoGuidUri = '';
var sourceVideoDataUri = '';

app.use(express.bodyParser());


// Handle GET : /orchestration-node-example
app.get('/', function(req, res) {

    // Get KVM data
    var kvm = apigee.getKeyValueMap('orchestration', 'environment');
    kvm.get('baseUrl', function(err, keyValue) {
        baseUrl = keyValue;
        apigee.setVariable(res, 'baseUrl', baseUrl);
    });
    kvm.get('authKey', function(err, keyValue) {
        authKey = keyValue;
        apigee.setVariable(res, 'authKey', keyValue);
    });
    kvm.get('sourceVideoGuidUri', function(err, keyValue) {
        sourceVideoGuidUri = keyValue;
        apigee.setVariable(res, 'sourceVideoGuidUri', keyValue);
    });
    kvm.get('sourceVideoDataUri', function(err, keyValue) {
        sourceVideoDataUri = keyValue;
        apigee.setVariable(res, 'sourceVideoDataUri', keyValue);
    });

    var optionsGlobal = {
        host: baseUrl,
        sourceVideoGuidUri: sourceVideoGuidUri,
        sourceVideoDataUri: sourceVideoDataUri,
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': authKey,
        }
    };

    fetchVideoGuids(optionsGlobal, res);
});

/**
 * fetchVideoGuids
 * Grab the videoGuids to fetch more details on
 * @param {object} optionsGlobal
 * @param {object} mainResponse
 */
function fetchVideoGuids(optionsGlobal, mainResponse) {
    var options = optionsGlobal;
    options.path = optionsGlobal.sourceVideoGuidUri;
    https.request(options, function(response) {
        var body = '';
        var videoGuids = [];
        response.on('data', function(d) {
            body += d;
        });
        response.on('end', function() {
            // Parse the body response to json object
            var jsonObject = JSON.parse(body);
            var workoutGroups = jsonObject.programs[0].workoutGroups || [];
            var totalWorkoutGroups = workoutGroups.length;
            var workouts = [];
            var totalWorkouts = 0;

            // Found workouts, let's grab the Guids
            if (totalWorkoutGroups > 0) {
                for (var wgIdx = 0; wgIdx < totalWorkoutGroups; wgIdx++) {
                    workouts = workoutGroups[wgIdx].workouts;
                    totalWorkouts = workouts.length;
                    for (var wIdx = 0; wIdx < totalWorkouts; wIdx++) {
                        videoGuids.push(workouts[wIdx].guid);
                    }
                }

                // Fetch video content data for videoGuids
                fetchVideoDetails(videoGuids, optionsGlobal, mainResponse);
            }
        });
    }).end();
}

/**
 * fetchVideoDetails
 * Fetch the video content for the specified videoGuids
 * @param {string} videoGuids
 * @param {object} optionsGlobal
 * @param {object} mainResponse
 */
function fetchVideoDetails(videoGuidsArr, optionsGlobal, mainResponse) {
    var options = optionsGlobal;
    var videoGuids = videoGuidsArr.join();
    options.path = optionsGlobal.sourceVideoDataUri + '?videoGuid=' + videoGuids;
    https.request(options, function(videoDetailsResponse) {
        var body = '';
        videoDetailsResponse.on('data', function(d) {
            body += d;
        });
        videoDetailsResponse.on('end', function() {
            var jsonObject = JSON.parse(body);
            var total = (jsonObject.hits && jsonObject.hits.records) || 0;
            var videoData = {};
            var videoDataSorted = [];
            for (var x = 0; x < total; x++) {
                videoGuid = jsonObject.items[x].videoGuid || '';
                workoutTitle = jsonObject.items[x].title || '';
                programTitle = jsonObject.items[x].programTitle || '';
                images = jsonObject.items[x].images || {};
                videoData[videoGuid] = {
                    videoGuid: videoGuid,
                    programName: programTitle,
                    programImage: images,
                    workoutTitle: workoutTitle,
                }
            }

            // Sort the data in the order it was requested
            for (x = 0; x < videoGuidsArr.length; x++) {
                videoGuid = videoGuidsArr[x] || '';
                videoDataSorted.push(videoData[videoGuid]);
            }

            jsonObject = {
                videoData: videoDataSorted,
            }

            var jsonResponse = JSON.stringify(jsonObject);
            sendResponse(mainResponse, jsonResponse);
        });
    }).end();
}

/**
 * sendResponse
 * Send the response out
 * @param {object} resp
 * @param {string} json
 */
function sendResponse(resp, json) {
    resp.setHeader('content-type', 'application/json');
    resp.send(json);
}

// Listen for requests until the server is stopped
app.listen(process.env.PORT || 9000);