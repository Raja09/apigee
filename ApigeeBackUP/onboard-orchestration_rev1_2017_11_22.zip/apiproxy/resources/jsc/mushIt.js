response.content = '';
response.headers['Content-Type'] = 'application/json';

try{
    
    var res = {};
    var onboardURL = 'https://gist.githubusercontent.com/rsekhaross/87b50be04930762e71683d5d830376c8/raw/e96cfe010f16f36fe6c1dc59bfd047ce061835d4/onboarding.json';
    var headers = { 'Content-Type' : 'application/json', 'Accept' : 'application/json' };
    
    var onboardReq = new Request(onboardURL, "GET", headers);
    var onboardRes = httpClient.send(onboardReq);
        
    onboardRes.waitForComplete();
    //tempResponse = temp.getResponse().content.asJSON;
    //tempResponse = eval('(' + temp.getResponse().content + ')');
    //programItems = tempResponse;
    
    onboardResponse = JSON.parse(onboardRes.getResponse().content);
    
    var brandCodeArr = {};

    for(var i in onboardResponse) {
        for(var j in onboardResponse[i]){
            brandCodeArr[j] = onboardResponse[i][j].programBrandCode;
            /*
            for(var k in onboardResponse[i][j]){
                if(onboardResponse[i][j][k].programBrandCode !== undefined){
                    brandCodeArr.push(onboardResponse[i][j][k].programBrandCode);
                }
            }
            */
        }
    }
    
    var res = {};

      for(var i in brandCodeArr) {
          
        var brandCode = brandCodeArr[i];
        
        var programsURL = 'http://content-dom-origin.api.beachbodyondemand.com/v3/programs/'+brandCode;
        //var headers = { 'Content-Type' : 'application/json', 'Accept' : 'application/json' };
        
        var programReq = new Request(programsURL, "GET", headers);
        var programRes = httpClient.send(programReq);
        
        programRes.waitForComplete();
        programResponse = programRes.getResponse().content.asJSON;

        res[brandCode] = programResponse.items;
    }

        var body = response.content.asJSON;
        body.items = res;
    
    //print(brandCodeArr);
    //var body = response.content.asJSON;
   // body.items = JSON.stringify(brandCodeArr);
    
}catch(err){
    response.content.asJSON.error = err;
}