response.content = '';
response.headers['Content-Type'] = 'application/json';

try{
    
    var resStatus = context.targetResponse.status; 
    
    var res = {};
    var req_verb = context.getVariable('request.verb');
    var req_uri = context.getVariable('request.uri');
    var req_org = context.getVariable('organization.name');
    var req_apiName = context.getVariable('apiproxy.name');
    var req_env = context.getVariable('environment.name');
   // var targetServerResCode = status; //context.getVariable('response.status.code');
   var response1 = context.getVariable("newrequest.content");//context.targetResponse.content.asJSON;
    
    //'beachbody__test__content-api-programs-v2__default__/v2/programs__GET'
    var cacheKey = req_org+'__'+req_env+'__'+req_apiName+'__default__'+req_uri+'__'+req_verb;
    
    var baseURL = 'https://api.usergrid.com/'+req_org+'/sandbox/caches';
    var headers = { 'Content-Type' : 'application/json', 'Accept' : 'application/json' };
    
    if(context.flow == "TARGET_RESP_FLOW" && resStatus == 200){
        
        var temp1URI = '?limit=1&ql='+encodeURIComponent("select cacheResponse where cacheKey='"+cacheKey+"' order by created desc");
        var temp1URL = baseURL+temp1URI;
        var temp1Req = new Request(temp1URL, 'GET', headers);
        var temp1Res = httpClient.send(temp1Req);
        
        temp1Res.waitForComplete();
        temp1Response = temp1Res.getResponse().content.asJSON;
        
        
         var body = {'cacheKey': cacheKey, 'cacheResponse': response1};
        if(temp1Response.length > 0){
            var Req = new Request(baseURL, "PUT", headers, JSON.stringify(body));
            var Res = httpClient.send(Req);
            
            Res.waitForComplete();
            Response = Res.getResponse().content.asJSON;
            
            tempResponse = JSON.parse(response1);
            res = tempResponse.items;
        }else{
            var Req = new Request(baseURL, "POST", headers, JSON.stringify(body));
            var Res = httpClient.send(Req);
            
            Res.waitForComplete();
            Response = Res.getResponse().content.asJSON;
            
            tempResponse = JSON.parse(response1);
            res = tempResponse.items;
        }
        /*
        var body = {'cacheKey': cacheKey, 'cacheResponse': response1};
        
        var Req = new Request(baseURL, "PUT", headers, JSON.stringify(body));
        var Res = httpClient.send(Req);
        
        Res.waitForComplete();
        Response = Res.getResponse().content.asJSON;
        
        res = Response.items;
        
        var body = response.content.asJSON;
        body.cacheKey = cacheKey;
        body.items = context.getVariable("newrequest.content");
        */
 
        //body.pqr = '1';
    }else { //if(context.flow == "TARGET_RESP_FLOW" && resStatus != 200){
        var temp1URI ='?limit=1&ql='+encodeURIComponent("select cacheResponse where cacheKey='"+cacheKey+"' order by created desc");
        var temp1URL = baseURL+temp1URI;
        var Req = new Request(temp1URL, "GET", headers);
        var Res = httpClient.send(Req);
        
        Res.waitForComplete();
        Response = Res.getResponse().content.asJSON;
        
        res = JSON.parse(Response.list);
        res = res.items;
    }

    var body = response.content.asJSON;
    body.items = res;
    
}catch(err){
    response.content.asJSON.error = err;
}